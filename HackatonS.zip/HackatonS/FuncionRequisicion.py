

import numpy as np
import pandas as pd
import datetime
import uuid
from datetime import datetime
from docxtpl import  DocxTemplate
import locale
import random

productos = pd.read_excel('productos.xlsx')
productos.set_index('product')
productosTienda = list(productos['product'])

locale.setlocale(locale.LC_MONETARY, 'en_US.UTF-8')

def elimina_ceros(original):
    nueva = []
    for dato in original:
        if dato != 0:
            nueva.append(dato)
            return nueva



def current_date_format(date):
    day = date.day
    month = date.month
    year = date.year
    messsage = "{}-{} del {}".format(day, month, year)

    return messsage

def crearCotizacion( nombre, productosz, cantidades, destino, Carrier_name, Planned_Delivery_Time, Distance  ):
        word_template_path ="template.docx"        
        dates = datetime.now()
        fecha = current_date_format(dates)
        source = 'LAX'
        precios = []
        unidades = []
        total = []
        subtotal = 0
        itmbs = 0
        totalitmbs = 0
        numCotizacion = random.randrange(1, 10000, 1)
                     

        for x in productosz:
            aux = productos.loc[ productos['product'] == x, 'price' ]   
            aux2 = productosTienda.index( x ) 
            precios.append( aux[aux2] )

            auxP = productos.loc[ productos['product'] == x, 'unidades' ]
            aux2P = productosTienda.index( x ) 
            unidades.append( auxP[aux2P] )
            

        for x in range(6):
            if( len(productosz) < 5 ):
                productosz.append('')
                precios.append('')
                cantidades.append('')
                unidades.append('')
                total.append(0)
            else:
                break;
        
        for x in enumerate(precios):
            if( precios[ x[0] ] != '' ):
                total[ x[0] ] = float (precios[ x[0] ] * cantidades[ x[0] ])
        

        total = elimina_ceros( total )            
   
        subtotal = sum( total )
        itmbs = round(subtotal * 0.07, 2)
        totalitmbs = round(subtotal + itmbs, 2)
        subtotal = locale.currency( subtotal )
        itmbs = locale.currency( itmbs )
        totalitmbs = locale.currency( totalitmbs )

        for x in enumerate(precios):
            if( precios[ x[0] ] != '' ):
                precios[ x[0] ] = locale.currency( precios[ x[0] ] )
                total[ x[0] ] = locale.currency( total[ x[0] ] ) 
    

       

        variables = {'producto': productosz, 
                     'cantidad': cantidades, 
                     'destino': destino, 
                     'fecha': fecha,
                     'precio': precios,
                     'unidades': unidades,
                     'source': source,
                     'carrier': Carrier_name,
                     'planned_delivey': Planned_Delivery_Time,
                     'distance': Distance,
                     'nombre': nombre,
                     'total': total,
                     'subtotal': subtotal,
                     'itmbs': itmbs,
                     'totalitmbs': totalitmbs,
                     'numCotizacion': numCotizacion
                     
                     }
        
        doc = DocxTemplate(word_template_path)
        doc.render( variables )
        doc.save( f"Cotizacion.docx")
    


